#include "../Helper_Functions.h"
#include "../Recursive_fft.h"
#include "../iterative_fft.h"
#include "../dft.h"
#include "../karatsuba.h"
#include "../Naive_Polynomial_Multiplication.h"
#include <check.h>

void Runtime_test(int n, int iterations);